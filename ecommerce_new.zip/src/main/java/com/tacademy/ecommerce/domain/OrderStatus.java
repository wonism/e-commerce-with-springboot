package com.tacademy.ecommerce.domain;

public enum OrderStatus {
  ORDERED, PREPARING, DELIVERY, COMPLETE, CANCELED
}
