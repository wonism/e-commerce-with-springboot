package com.tacademy.ecommerce.domain;

public enum PayMethod {
  CARD, CASH
}
