package com.tacademy.ecommerce.security;

public final class Authorities {

	private Authorities() {}

	public static final String ADMIN = "ADMIN";
	public static final String USER = "USER";

}
