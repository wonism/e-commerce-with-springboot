package com.tacademy.ecommerce.service;

import java.util.HashSet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.tacademy.ecommerce.domain.Authority;
import com.tacademy.ecommerce.domain.User;
import com.tacademy.ecommerce.repository.AuthorityRepository;
import com.tacademy.ecommerce.repository.UserRepository;
import com.tacademy.ecommerce.security.Authorities;

@Service
public class UserManager {

  @Autowired
  private UserRepository userRepository;

  @Autowired
  private AuthorityRepository authorityRepository;

  public boolean existUserByUsername(String username) {
    return findByUsername(username) != null;
  }

  @Transactional
  public User save(User user) {
	  Authority authority = authorityRepository.findByAuthority(Authorities.USER);
	  
	  userRepository.save(new HashSet<User>() {
			{
				add(new User(user.getName(), 
						user.getPassword(), 
						user.getUsername(),   
						new HashSet<Authority>() {{					
						   add(authority);					
				        }}
				));
			}
		});

		return user;

  }

  public User findByUsername(String username) {
    User user = userRepository.findByUsername(username);
    return user;
  }

  public Authority findByAuthority(String authority) {
    return authorityRepository.findByAuthority(authority);
  }


}
